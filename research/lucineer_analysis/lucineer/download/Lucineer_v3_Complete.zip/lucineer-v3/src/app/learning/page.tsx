"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import {
  BookOpen, Gamepad2, Clock, GraduationCap, Briefcase,
  ChevronRight, ArrowRight, Play, Star, Lock, Unlock,
  Zap, Target, Award, TrendingUp, Users
} from "lucide-react";

const ageGroups = [
  {
    id: "young",
    title: "Young Learners",
    age: "4-10",
    icon: Gamepad2,
    color: "#3b82f6",
    gradient: "from-blue-500 to-cyan-500",
    description: "Learn through play with traffic lights, musical chairs, and domino chains.",
    modules: [
      { name: "Traffic Light Timing", lessons: 8, difficulty: "Easy", icon: "🚦" },
      { name: "Musical Chairs Fun", lessons: 6, difficulty: "Easy", icon: "🎵" },
      { name: "Domino Chain Reactions", lessons: 10, difficulty: "Easy", icon: "🎲" },
      { name: "Baking Timer Games", lessons: 5, difficulty: "Easy", icon: "🍪" },
    ],
  },
  {
    id: "middle",
    title: "Middle School",
    age: "11-14",
    icon: Clock,
    color: "#8b5cf6",
    gradient: "from-purple-500 to-pink-500",
    description: "Animation timing, music beat programming, and traffic systems.",
    modules: [
      { name: "Animation Frame Timing", lessons: 12, difficulty: "Medium", icon: "🎬" },
      { name: "Beat Programming", lessons: 8, difficulty: "Medium", icon: "🥁" },
      { name: "Traffic Flow Systems", lessons: 10, difficulty: "Medium", icon: "🚗" },
      { name: "Sports Replay Analysis", lessons: 6, difficulty: "Medium", icon: "⚽" },
    ],
  },
  {
    id: "high",
    title: "High School",
    age: "15-18",
    icon: GraduationCap,
    color: "#f59e0b",
    gradient: "from-amber-500 to-orange-500",
    description: "Digital logic timing, assembly line optimization, system design.",
    modules: [
      { name: "Digital Logic Intro", lessons: 15, difficulty: "Advanced", icon: "⚡" },
      { name: "Timing Analysis", lessons: 12, difficulty: "Advanced", icon: "📊" },
      { name: "System Design Basics", lessons: 10, difficulty: "Advanced", icon: "🔧" },
      { name: "CPU State Machines", lessons: 8, difficulty: "Advanced", icon: "💻" },
    ],
  },
  {
    id: "pro",
    title: "Professional",
    age: "18+",
    icon: Briefcase,
    color: "#22c55e",
    gradient: "from-green-500 to-emerald-500",
    description: "FPGA timing closure, CDC analysis, pipeline optimization, real chip design.",
    modules: [
      { name: "FPGA Timing Closure", lessons: 20, difficulty: "Expert", icon: "🔬" },
      { name: "CDC Analysis", lessons: 15, difficulty: "Expert", icon: "📈" },
      { name: "Pipeline Optimization", lessons: 12, difficulty: "Expert", icon: "⚙️" },
      { name: "Real Chip Design", lessons: 25, difficulty: "Expert", icon: "🧠" },
    ],
  },
];

export default function LearningPage() {
  const searchParams = useSearchParams();
  const selectedAge = searchParams.get("age") || "young";

  const activeGroup = ageGroups.find((g) => g.id === selectedAge) || ageGroups[0];

  return (
    <div className="animated-bg min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold">Learning Center</h1>
              <p className="text-sm text-gray-500">All ages, infinite depth</p>
            </div>
          </div>

          <p className="text-xl text-gray-300 max-w-3xl">
            Master timing concepts that power AI through interactive modules. 
            Same fundamentals, different depths for every age group.
          </p>
        </div>

        {/* Age Group Selector */}
        <div className="flex flex-wrap gap-3 mb-8">
          {ageGroups.map((group) => (
            <Link
              key={group.id}
              href={`/learning?age=${group.id}`}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl font-medium transition-all ${
                selectedAge === group.id
                  ? `bg-gradient-to-r ${group.gradient} text-white`
                  : "bg-dark-700/50 text-gray-400 hover:text-white border border-dark-600"
              }`}
            >
              <group.icon className="w-5 h-5" />
              <div>
                <div className="text-sm font-semibold">{group.title}</div>
                <div className="text-xs opacity-75">Ages {group.age}</div>
              </div>
            </Link>
          ))}
        </div>

        {/* Active Group Content */}
        <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-dark-600 overflow-hidden mb-8">
          <div className={`p-6 bg-gradient-to-r ${activeGroup.gradient} bg-opacity-10`}>
            <div className="flex items-center gap-4">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center"
                style={{ background: `linear-gradient(135deg, ${activeGroup.color}40 0%, ${activeGroup.color}20 100%)` }}
              >
                <activeGroup.icon className="w-8 h-8" style={{ color: activeGroup.color }} />
              </div>
              <div>
                <h2 className="text-2xl font-bold">{activeGroup.title}</h2>
                <p className="text-gray-400">Ages {activeGroup.age} • {activeGroup.modules.reduce((acc, m) => acc + m.lessons, 0)} lessons</p>
              </div>
            </div>
            <p className="mt-4 text-gray-300">{activeGroup.description}</p>
          </div>

          {/* Module Grid */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeGroup.modules.map((module, index) => (
                <div
                  key={module.name}
                  className="p-4 rounded-xl bg-dark-700/30 border border-dark-600 hover:border-green-500/30 transition-all cursor-pointer group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{module.icon}</span>
                      <div>
                        <h3 className="font-semibold group-hover:text-green-400 transition-colors">
                          {module.name}
                        </h3>
                        <p className="text-xs text-gray-500">{module.lessons} lessons</p>
                      </div>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      module.difficulty === "Easy" ? "bg-green-500/20 text-green-400" :
                      module.difficulty === "Medium" ? "bg-amber-500/20 text-amber-400" :
                      module.difficulty === "Advanced" ? "bg-orange-500/20 text-orange-400" :
                      "bg-red-500/20 text-red-400"
                    }`}>
                      {module.difficulty}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${i < 3 ? "text-yellow-500 fill-yellow-500" : "text-gray-600"}`}
                        />
                      ))}
                    </div>
                    <button className="flex items-center gap-1 text-green-400 text-sm font-medium group-hover:gap-2 transition-all">
                      Start <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-dark-800/60 rounded-xl p-4 border border-dark-600">
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 text-blue-400" />
              <div>
                <div className="text-2xl font-bold">100+</div>
                <div className="text-xs text-gray-500">Lessons</div>
              </div>
            </div>
          </div>
          <div className="bg-dark-800/60 rounded-xl p-4 border border-dark-600">
            <div className="flex items-center gap-3">
              <Award className="w-5 h-5 text-amber-400" />
              <div>
                <div className="text-2xl font-bold">4</div>
                <div className="text-xs text-gray-500">Age Groups</div>
              </div>
            </div>
          </div>
          <div className="bg-dark-800/60 rounded-xl p-4 border border-dark-600">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <div>
                <div className="text-2xl font-bold">∞</div>
                <div className="text-xs text-gray-500">Offline Access</div>
              </div>
            </div>
          </div>
          <div className="bg-dark-800/60 rounded-xl p-4 border border-dark-600">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-purple-400" />
              <div>
                <div className="text-2xl font-bold">$0</div>
                <div className="text-xs text-gray-500">Cost (Free)</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
