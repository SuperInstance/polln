"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import {
  Cpu, Chip, Layers, Box, Code, Zap, ArrowRight, Download,
  Play, Pause, RotateCcw, Settings, Maximize2, ChevronRight,
  Lightbulb, Target, Globe, FileCode, Microscope, Sparkles,
  GitBranch, BoxIcon, CircuitBoard, Binary, Gauge, Factory
} from "lucide-react";

// Voxel Block Component for 3D-like representation
function VoxelBlock({ color, size = 40, delay = 0 }: { color: string; size?: number; delay?: number }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  return (
    <div
      className={`transition-all duration-500 ${visible ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}
      style={{
        width: size,
        height: size,
        background: `linear-gradient(135deg, ${color} 0%, ${color}dd 100%)`,
        boxShadow: `inset -2px -2px 4px rgba(0,0,0,0.3), inset 2px 2px 4px rgba(255,255,255,0.1), 0 4px 8px rgba(0,0,0,0.3)`,
        borderRadius: 4,
      }}
    />
  );
}

// Progressive Iteration Layers
const iterationLayers = [
  {
    level: 0,
    title: "Use Case Vision",
    icon: Lightbulb,
    color: "#f59e0b",
    description: "Start with your real-world application",
    example: "Smart downrigger for Sitka salmon fishing",
    outputs: ["Problem statement", "User requirements", "Environmental constraints"],
  },
  {
    level: 1,
    title: "System Architecture",
    icon: GitBranch,
    color: "#8b5cf6",
    description: "Define high-level components and data flow",
    example: "Depth sensor → MCU → Motor controller → Display",
    outputs: ["Block diagram", "Component list", "Interfaces"],
  },
  {
    level: 2,
    title: "Hardware Selection",
    icon: CircuitBoard,
    color: "#3b82f6",
    description: "Choose chips, sensors, and peripherals",
    example: "ESP32-C3 + MS5837 pressure sensor + H-bridge",
    outputs: ["BOM", "Pin assignments", "Power budget"],
  },
  {
    level: 3,
    title: "PCB Design",
    icon: Layers,
    color: "#22c55e",
    description: "Layout and physical form factor",
    example: "Circular PCB, 50mm diameter, IP68 enclosure",
    outputs: ["Schematic", "Layout", "Stackup"],
  },
  {
    level: 4,
    title: "AI Model",
    icon: Box,
    color: "#ec4899",
    description: "Optimize neural network for edge",
    example: "BitNet 0.73B, Int4 quantization, 200KB",
    outputs: ["Model weights", "Inference code", "Memory map"],
  },
  {
    level: 5,
    title: "Chip Schema",
    icon: FileCode,
    color: "#10b981",
    description: "Ready for EDA tools",
    example: "chip.v + constraints.sdc + timing.cfg",
    outputs: ["Verilog", "Constraints", "Test bench"],
  },
];

// Example Projects
const exampleProjects = [
  {
    title: "Smart Downrigger",
    domain: "Marine Electronics",
    description: "Depth-aware fishing equipment with AI-powered fish detection",
    components: ["ESP32-C3", "Pressure sensor", "Motor driver", "BLE"],
    difficulty: "Intermediate",
  },
  {
    title: "Edge AI Camera",
    domain: "Computer Vision",
    description: "Low-power object detection with on-device inference",
    components: ["Cyclone V FPGA", "Camera module", "SD card", "USB"],
    difficulty: "Advanced",
  },
  {
    title: "Weather Station",
    domain: "IoT",
    description: "Solar-powered environmental monitoring with ML predictions",
    components: ["RP2040", "BME280", "Solar panel", "LoRa"],
    difficulty: "Beginner",
  },
];

// Voxel presets for different chip types
const chipPresets = [
  { name: "MCU Core", blocks: 8, colors: ["#3b82f6", "#60a5fa", "#2563eb"] },
  { name: "Memory Array", blocks: 16, colors: ["#8b5cf6", "#a78bfa", "#7c3aed"] },
  { name: "AI Accelerator", blocks: 12, colors: ["#ec4899", "#f472b6", "#db2777"] },
  { name: "I/O Block", blocks: 6, colors: ["#22c55e", "#4ade80", "#16a34a"] },
];

export default function TernaryAirPage() {
  const [activeLayer, setActiveLayer] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState(0);

  // Auto-cycle through layers when playing
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setActiveLayer((prev) => (prev + 1) % iterationLayers.length);
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  return (
    <div className="animated-bg min-h-screen pt-24 pb-16">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold">
              <span className="gradient-text">TernaryAir</span>
            </h1>
            <p className="text-sm text-gray-500">Chip Design Studio</p>
          </div>
        </div>

        <p className="text-xl text-gray-300 max-w-3xl">
          Design real AI chips with <span className="text-green-400 font-semibold">Lucineer</span>, your AI co-inventor.
          Start from a use case and progressively iterate until you have Cadence-ready schemas.
        </p>
      </div>

      {/* Main Content Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Left Column: Progressive Iteration */}
          <div className="lg:col-span-2 space-y-6">

            {/* Iteration Layers */}
            <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-dark-600 overflow-hidden">
              <div className="p-4 border-b border-dark-600 bg-dark-700/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Microscope className="w-5 h-5 text-green-400" />
                  <span className="font-semibold">Progressive Iteration Engine</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-2 rounded-lg bg-dark-600 hover:bg-dark-500 transition-colors"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setActiveLayer(0)}
                    className="p-2 rounded-lg bg-dark-600 hover:bg-dark-500 transition-colors"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                {/* Layer Navigation */}
                <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
                  {iterationLayers.map((layer, index) => (
                    <button
                      key={layer.level}
                      onClick={() => setActiveLayer(index)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-all ${
                        activeLayer === index
                          ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                          : 'bg-dark-700/50 text-gray-400 hover:text-white'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-mono"
                        style={{ background: activeLayer === index ? layer.color : '#40414f' }}>
                        {layer.level}
                      </span>
                      <span className="hidden sm:inline">{layer.title}</span>
                    </button>
                  ))}
                </div>

                {/* Active Layer Detail */}
                <div className="bg-dark-700/50 rounded-xl p-6 border border-dark-600">
                  <div className="flex items-start gap-4 mb-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ background: `linear-gradient(135deg, ${iterationLayers[activeLayer].color}40 0%, ${iterationLayers[activeLayer].color}20 100%)` }}
                    >
                      {(() => {
                        const IconComponent = iterationLayers[activeLayer].icon;
                        return <IconComponent className="w-6 h-6" style={{ color: iterationLayers[activeLayer].color }} />;
                      })()}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-1">
                        {iterationLayers[activeLayer].title}
                      </h3>
                      <p className="text-gray-400 text-sm">
                        {iterationLayers[activeLayer].description}
                      </p>
                    </div>
                  </div>

                  <div className="bg-dark-800/50 rounded-lg p-4 mb-4">
                    <div className="text-xs text-gray-500 mb-2">Example Output:</div>
                    <code className="text-green-400 text-sm font-mono">
                      {iterationLayers[activeLayer].example}
                    </code>
                  </div>

                  <div className="space-y-2">
                    <div className="text-xs text-gray-500 mb-2">Deliverables:</div>
                    <div className="flex flex-wrap gap-2">
                      {iterationLayers[activeLayer].outputs.map((output) => (
                        <span
                          key={output}
                          className="px-3 py-1 rounded-full text-xs bg-dark-600 text-gray-300 border border-dark-500"
                        >
                          {output}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Voxel Playground */}
            <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-dark-600 overflow-hidden">
              <div className="p-4 border-b border-dark-600 bg-dark-700/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BoxIcon className="w-5 h-5 text-purple-400" />
                  <span className="font-semibold">Voxel Playground</span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-lg bg-dark-600 hover:bg-dark-500 transition-colors">
                    <Settings className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg bg-dark-600 hover:bg-dark-500 transition-colors">
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                {/* Preset Selector */}
                <div className="flex items-center gap-2 mb-6">
                  {chipPresets.map((preset, index) => (
                    <button
                      key={preset.name}
                      onClick={() => setSelectedPreset(index)}
                      className={`px-3 py-2 rounded-lg text-sm transition-all ${
                        selectedPreset === index
                          ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                          : 'bg-dark-700/50 text-gray-400 hover:text-white'
                      }`}
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>

                {/* Voxel Grid */}
                <div className="bg-dark-700/30 rounded-xl p-8 border border-dark-600">
                  <div className="flex flex-wrap justify-center gap-2">
                    {Array.from({ length: chipPresets[selectedPreset].blocks }).map((_, i) => (
                      <VoxelBlock
                        key={i}
                        color={chipPresets[selectedPreset].colors[i % 3]}
                        size={32}
                        delay={i * 50}
                      />
                    ))}
                  </div>

                  <div className="text-center mt-6">
                    <p className="text-gray-500 text-sm">
                      {chipPresets[selectedPreset].name} • {chipPresets[selectedPreset].blocks} functional units
                    </p>
                  </div>
                </div>

                {/* Controls */}
                <div className="mt-6 flex items-center justify-center gap-4">
                  <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-dark-600 hover:bg-dark-500 text-sm transition-colors">
                    <RotateCcw className="w-4 h-4" />
                    Reset
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-dark-600 hover:bg-dark-500 text-sm transition-colors">
                    <Binary className="w-4 h-4" />
                    Export Verilog
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-sm transition-colors">
                    <FileCode className="w-4 h-4" />
                    Generate Schema
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Tools & Resources */}
          <div className="space-y-6">

            {/* Quick Start */}
            <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-dark-600 overflow-hidden">
              <div className="p-4 border-b border-dark-600 bg-dark-700/50">
                <div className="flex items-center gap-3">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <span className="font-semibold">Quick Start</span>
                </div>
              </div>

              <div className="p-4 space-y-3">
                <Link
                  href="/ternaryair/new"
                  className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 transition-all"
                >
                  <Lightbulb className="w-5 h-5" />
                  <div>
                    <div className="font-medium">New Project</div>
                    <div className="text-xs text-green-100">Start from scratch</div>
                  </div>
                  <ArrowRight className="w-4 h-4 ml-auto" />
                </Link>

                <Link
                  href="/ternaryair/templates"
                  className="flex items-center gap-3 p-3 rounded-xl bg-dark-700/50 hover:bg-dark-600 border border-dark-600 transition-all"
                >
                  <Layers className="w-5 h-5 text-purple-400" />
                  <div>
                    <div className="font-medium">Templates</div>
                    <div className="text-xs text-gray-500">Pre-built designs</div>
                  </div>
                  <ArrowRight className="w-4 h-4 ml-auto text-gray-500" />
                </Link>

                <Link
                  href="/ternaryair/import"
                  className="flex items-center gap-3 p-3 rounded-xl bg-dark-700/50 hover:bg-dark-600 border border-dark-600 transition-all"
                >
                  <Download className="w-5 h-5 text-blue-400" />
                  <div>
                    <div className="font-medium">Import Design</div>
                    <div className="text-xs text-gray-500">From Verilog or EDIF</div>
                  </div>
                  <ArrowRight className="w-4 h-4 ml-auto text-gray-500" />
                </Link>
              </div>
            </div>

            {/* Example Projects */}
            <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-dark-600 overflow-hidden">
              <div className="p-4 border-b border-dark-600 bg-dark-700/50">
                <div className="flex items-center gap-3">
                  <Target className="w-5 h-5 text-cyan-400" />
                  <span className="font-semibold">Example Projects</span>
                </div>
              </div>

              <div className="p-4 space-y-3">
                {exampleProjects.map((project) => (
                  <div
                    key={project.title}
                    className="p-3 rounded-xl bg-dark-700/30 hover:bg-dark-700/50 border border-dark-600 cursor-pointer transition-all"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-sm">{project.title}</h4>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        project.difficulty === 'Beginner' ? 'bg-green-500/20 text-green-400' :
                        project.difficulty === 'Intermediate' ? 'bg-amber-500/20 text-amber-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {project.difficulty}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mb-2">{project.domain}</p>
                    <p className="text-xs text-gray-400 mb-2">{project.description}</p>
                    <div className="flex flex-wrap gap-1">
                      {project.components.map((comp) => (
                        <span key={comp} className="text-xs px-2 py-0.5 rounded bg-dark-600 text-gray-400">
                          {comp}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Lucineer Chat */}
            <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-green-500/30 overflow-hidden">
              <div className="p-4 border-b border-dark-600 bg-gradient-to-r from-green-900/30 to-emerald-900/30">
                <div className="flex items-center gap-3">
                  <Sparkles className="w-5 h-5 text-green-400" />
                  <span className="font-semibold">Lucineer Co-Inventor</span>
                </div>
              </div>

              <div className="p-4">
                <div className="bg-dark-700/50 rounded-xl p-4 mb-4 text-sm text-gray-300">
                  <p className="mb-2">
                    I&apos;m Lucineer, your AI co-inventor. I help you design chips by:
                  </p>
                  <ul className="space-y-1 text-gray-400">
                    <li>• Understanding your use case</li>
                    <li>• Suggesting architectures</li>
                    <li>• Optimizing for constraints</li>
                    <li>• Generating EDA-ready code</li>
                  </ul>
                </div>

                <button className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 font-medium transition-all">
                  <Sparkles className="w-4 h-4" />
                  Start Co-Inventing
                </button>
              </div>
            </div>

            {/* Resources */}
            <div className="bg-dark-800/80 backdrop-blur-lg rounded-2xl border border-dark-600 overflow-hidden">
              <div className="p-4 border-b border-dark-600 bg-dark-700/50">
                <div className="flex items-center gap-3">
                  <Gauge className="w-5 h-5 text-orange-400" />
                  <span className="font-semibold">Resources</span>
                </div>
              </div>

              <div className="p-4 space-y-2">
                <Link
                  href="/research?tag=chip-design"
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-dark-700/50 transition-colors text-sm"
                >
                  <FileCode className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-300">Chip Design Docs</span>
                  <ChevronRight className="w-4 h-4 ml-auto text-gray-600" />
                </Link>
                <Link
                  href="/research?tag=fpga"
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-dark-700/50 transition-colors text-sm"
                >
                  <CircuitBoard className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-300">FPGA Guides</span>
                  <ChevronRight className="w-4 h-4 ml-auto text-gray-600" />
                </Link>
                <Link
                  href="/research?tag=timing"
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-dark-700/50 transition-colors text-sm"
                >
                  <Gauge className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-300">Timing Analysis</span>
                  <ChevronRight className="w-4 h-4 ml-auto text-gray-600" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Learning Center Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <h2 className="text-2xl font-bold mb-6">Learn Chip Design</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link
            href="/ternaryair/tutorials"
            className="group p-6 rounded-2xl bg-dark-800/80 border border-dark-600 hover:border-green-500/30 transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center mb-4">
              <Lightbulb className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold mb-2">Tutorials</h3>
            <p className="text-sm text-gray-400">Visual learning from basics to advanced chip design</p>
            <ArrowRight className="w-4 h-4 mt-3 text-green-400 group-hover:translate-x-1 transition-transform" />
          </Link>

          <Link
            href="/ternaryair/voxel-lab"
            className="group p-6 rounded-2xl bg-dark-800/80 border border-dark-600 hover:border-purple-500/30 transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center mb-4">
              <Box className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold mb-2">Voxel Lab</h3>
            <p className="text-sm text-gray-400">Build chips like building blocks - no experience needed</p>
            <ArrowRight className="w-4 h-4 mt-3 text-purple-400 group-hover:translate-x-1 transition-transform" />
          </Link>

          <Link
            href="/ternaryair/pcie"
            className="group p-6 rounded-2xl bg-dark-800/80 border border-dark-600 hover:border-blue-500/30 transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center mb-4">
              <CircuitBoard className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold mb-2">PCIe Designer</h3>
            <p className="text-sm text-gray-400">Design desktop AI accelerator cards</p>
            <ArrowRight className="w-4 h-4 mt-3 text-blue-400 group-hover:translate-x-1 transition-transform" />
          </Link>

          <Link
            href="/ternaryair/edge"
            className="group p-6 rounded-2xl bg-dark-800/80 border border-dark-600 hover:border-amber-500/30 transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center mb-4">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold mb-2">Edge Simulator</h3>
            <p className="text-sm text-gray-400">Configure AI devices for real-world deployment</p>
            <ArrowRight className="w-4 h-4 mt-3 text-amber-400 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="bg-gradient-to-r from-green-900/30 via-dark-800 to-emerald-900/30 rounded-2xl p-8 border border-green-500/20 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Design Your First Chip?</h2>
          <p className="text-gray-400 mb-6 max-w-xl mx-auto">
            Start with a use case, iterate with Lucineer, and export to Cadence or Synopsis when ready.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              href="/ternaryair/tutorials"
              className="inline-flex items-center gap-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white px-8 py-4 rounded-xl font-semibold transition-all shadow-lg"
            >
              <Lightbulb className="w-5 h-5" />
              Start Learning
            </Link>
            <Link
              href="/ternaryair/manufacturing"
              className="inline-flex items-center gap-3 bg-dark-700 hover:bg-dark-600 text-white px-8 py-4 rounded-xl font-semibold transition-all border border-dark-500"
            >
              <Factory className="w-5 h-5" />
              Manufacturing Options
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
